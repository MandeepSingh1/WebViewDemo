//
//  CustomWebView.h
//  CustomWebView
//
//  Created by Mandeep Singh on 16/07/19.
//  Copyright © 2019 Mandeep Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CustomWebView.
FOUNDATION_EXPORT double CustomWebViewVersionNumber;

//! Project version string for CustomWebView.
FOUNDATION_EXPORT const unsigned char CustomWebViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like

#import <CustomWebView/CustomWebView.h>


